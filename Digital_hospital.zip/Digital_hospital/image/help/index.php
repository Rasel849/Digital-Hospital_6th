<!DOCTYPE php>
<php>

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Help</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <link rel="stylesheet" href="help.css">
    </head>

    <body>
        <header class="header">

            <a href="#" class="logo">
                <img src="logo.png" alt="">
            </a>

        </header>

        <section class="contact" id="contact">


            <h1 class="heading"> <span>contact</span> us </h1>

            <div class="row">

                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3634.3747609336197!2d88.63543921540945!3d24.368263170807705!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fbf02db6d04b59%3A0xaa58eb411ea3ec5c!2sUniversity%20of%20Rajshahi!5e0!3m2!1sen!2sbd!4v1633783536019!5m2!1sen!2sbd"
                    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

                <form action="connect.php" method="post">

                    <form action="">

                        <div class="inputBox">
                            <span class="fas fa-user"></span>
                            <input type="text" name="name" id="name" placeholder="name">
                        </div>
                        <div class="inputBox">
                            <span class="fas fa-envelope"></span>
                            <input type="email" name="email" id="email" placeholder="email">
                        </div>
                        <div class="inputBox">
                            <span class="fas fa-phone"></span>
                            <input type="number" name="number" id="number" placeholder="number">
                        </div>
                        <div class="inputBox">
                            <span class="fas fa-envelope"></span>
                            <input type="text" name="massage" id="massage" placeholder="massage">
                        </div>
                        <input type="submit" value="contact now" class="btn">
                    </form>
                </form>

            </div>

        </section>


        <section class="finish">

            <div class="address">
                <h2>Address: Administration Building 1, Rajshahi</h2><br>
                <h4><span class="fas fa-phone"></span> Phone Number: +8801303679402</h4><br>
                <h4><span class="fas fa-envelope"></span> Email: raselislambabu0677@gmail.com</h4>
            </div>
            <div class="share">
                <a href="https://www.facebook.com/rasel.ahamed.927980" class="fab fa-facebook-f"></a>
                <a href="#" class="fab fa-twitter"></a>
                <a href="#" class="fab fa-linkedin"></a>
            </div>

        </section>

    </body>
</php>