<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Your message has been sent successfully</title>
<link href="succeess.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
</head>

<body>
    <header class="header">

        <a href="#" class="logo">
            <img src="logo.png" alt="">
        </a>

    </header>
<div class="cong">
    <form>
        <h2>আপনার মেসেজটি পর্যালোচনা করা হচ্ছে দয়া করে অপেক্ষা করুন</h2>
        <a href="index.php" style="text-decoration: none">Go back to Home page</a>
        <br><br>
    </form>
    
    </div>
</body>
</html>
