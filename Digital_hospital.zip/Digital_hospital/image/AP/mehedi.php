<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/datepicker.css">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>

    <body>
      <header class="header">

        <a href="#" class="logo">
            <img src="images/logo.png" alt="">
        </a>
    
        <nav class="navbar">
            <a href="#menu">Back</a>
        </nav> 
    </header>
      <div class="inner-layer">
        <br><br><br>
          <div class="container">
            <div class="row no-margin">
                <div class="col-sm-7">
                    <div class="content">
                      <img src="assets/images/hasib.PNG" alt="">
                        <h1>Md.Mehedi Hasan</h1>
                        <p>Specialities: Haematology<br>
                          Experiences Summary:<br>
                          MBBS, FCPS (Haematology). Dhaka Medical College & Hospital, Dhaka.<br>
                          Practicing Branch: Digital Hospita</p>
                    </div>
                </div>
                <div class="col-sm-5">
                 
                    <div class="form-data">
                        <div class="form-head">
                            <h2>Book Appointemnt</h2>
                        </div>
                        <div class="form-body">
                          <form action="connect.php" method="post">
                            <div class="row form-row">
                              <input type="text" 
                              placeholder="Enter Full name" 
                              id="name"
                              name="name"
                              class="form-control">
                            </div>
                            <div class="row form-row">
                              <input type="number"
                               placeholder="Enter Mobile Number"
                               id="number"
                               name="number"
                               class="form-control">
                            </div>
                             <div class="row form-row">
                              <input type="text" 
                              placeholder="Enter Email Adreess" 
                              id="email"
                              name="email"
                              class="form-control">
                            </div>
                           <div class="row form-row">
                              <input id="date"
                              name="date" 
                              type="text"
                               placeholder="Appointment Date" 
                               class="form-control">
                            </div>


                            <div class="form-group">
                              <label for="Time">Appointemnt Time</label>
                              <div>
                                <label for="08:00AM-11:30AM" class="radio-inline"
                                  ><input
                                    type="radio"
                                    name="Time"
                                    value="08:00AM-11:30AM"
                                    id="morn"
                                  />08:00AM-11:30AM</label
                                >
                                <label for="05:00PM-08:00PM" class="radio-inline"
                                  ><input
                                    type="radio"
                                    name="Time"
                                    value="05:00PM-08:00PM"
                                    id="even"
                                  />05:00PM-08:00PM</label
                                >
    
                              </div>
                            <div class="form-group">
                              <label for="gender">Gender</label>
                              <div>
                                <label for="male" class="radio-inline"
                                  ><input
                                    type="radio"
                                    name="gender"
                                    value="m"
                                    id="male"
                                  />Male</label
                                >
                                <label for="female" class="radio-inline"
                                  ><input
                                    type="radio"
                                    name="gender"
                                    value="f"
                                    id="female"
                                  />Female</label
                                >
                                <label for="others" class="radio-inline"
                                  ><input
                                    type="radio"
                                    name="gender"
                                    value="o"
                                    id="others"
                                  />Others</label
                                >
                              </div>
                            </div>

                             <div class="row form-row">
                               <button class="btn btn-success btn-appointment">
                                 Book Appointment
                               </button>
                               
                            </div>
                          </form>

                        </div>
                    </div>
                  
                </div>
            </div>
          </div>
      </div>
      
    </body>
  
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/bootstrap-datepicker.js"></script>

    <script>
      $(document).ready(function(){
          $("#date").datepicker();
      })
    </script>
    
  </body>
</html>