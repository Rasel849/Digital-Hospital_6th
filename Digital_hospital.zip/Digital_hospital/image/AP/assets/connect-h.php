<?php
	$name = $_POST['name'];
	$number = $_POST['number'];
	$email = $_POST['email'];
	$date =$_POST['date'];
	$Time =$_POST['Time'];
	$gender = $_POST['gender'];

	// Database connection
	$conn = new mysqli('localhost','root','','doctor');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into hasib(name,number, email,date,Time, gender) values(?, ?, ?,?,?, ?)");
		$stmt->bind_param("sissss", $name, $number, $email,$date,$Time, $gender);
		$execval = $stmt->execute();
		echo $execval;
		echo '<script>
          window.location="succeess.php";
        </script>';
		$stmt->close();
		$conn->close();
	}
?>