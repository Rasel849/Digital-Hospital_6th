<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Your message has been sent successfully</title>
<link href="succeess.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
</head>

<body>
    <header class="header">

        <a href="#" class="logo">
            <img src="images/logo.png" alt="">
        </a>

    </header>
<div class="cong">
    <form>
        <h2>আপনার রেজিস্ট্রেশন সম্পন্ন হয়েছে</h2>
       
        <br><br>
    </form>
    
    </div>
</body>
</html>
