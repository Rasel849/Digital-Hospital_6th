<?php
	$name = $_POST['name'];
	$number = $_POST['number'];
	$email = $_POST['email'];
	$area=$_POST['area'];
	$city=$_POST['city'];
	$state=$_POST['state'];
	$postal_code=$_POST['postal_code'];

	// Database connection
	$conn = new mysqli('localhost','root','','doctor');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into ambulance(name,number, email,area,city,state,postal_code) values(?, ?, ?,?,?, ?,?)");
		$stmt->bind_param("sisssss", $name, $number, $email,$area,$city, $state,$postal_code);
		$execval = $stmt->execute();
		echo $execval;
		
		echo '<script>
          window.location="rb.php";
        </script>';
		$stmt->close();
		$conn->close();
	}
?>