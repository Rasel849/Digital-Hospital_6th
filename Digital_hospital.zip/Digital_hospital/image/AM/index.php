<!DOCTYPE html>
<html>
  <head>
    <title>ONLINE APPOINTMENT BOOKING</title>
    <link rel="stylesheet" type="text/css" href="bootstap.css" />
  </head>
  <body>
       <header class="header">

    <a href="#" class="logo">
        <img src="logo.png" alt="">
    </a>

    <nav class="navbar">
        <a href="#menu">home</a>
    </nav>
</header>
    <div class="container">
      <div class="row col-md-6 col-md-offset-3">
        <div class="panel panel-primary">
          <div class="panel-heading text-center">
            <h1>AMBULANCE SERVICE</h1>
          </div>
          <div class="panel-body">
            <form action="connect.php" method="post">
              <div class="form-group">
                <input
                 placeholder="Enter Full name"
                  type="text"
                  class="form-control"
                  id="name"
                  name="name"
                />
              </div>
                 <div class="form-group">
                <label for="number">Phone Number</label>
                <input
                  type="number"
                  class="form-control"
                  id="number"
                  name="number"
                />
              </div>
                <div class="form-group">
                <label for="email">Email</label>
                <input
                  type="text"
                  class="form-control"
                  id="email"
                  name="email"
                />
              </div>
             
              <h6>Address Details</h6>

                             <div class="row form-row">
                                <div class="col-sm-6">
                                   <input type="text"id="area" name="area" placeholder="Enter Area" class="form-control">
                                </div>
                                <div class="col-sm-6">
                                   <input type="text"id="city" name="city" placeholder="Enter City" class="form-control">
                                </div>
                            </div>
                            <br>
                             <div class="row form-row">
                                <div class="col-sm-6">
                                   <input type="text"id="state" name="state" placeholder="Enter State" class="form-control">
                                </div>
                                <div class="col-sm-6">
                                   <input type="text"id="postal_code" name="postal_code" placeholder="Postal Code" class="form-control">
                                </div>
                            </div>
                            <br><br>
              <input type="submit" class="btn btn-primary" />
            </form>
          </div>
        </div>
      </div>
    </div>
  
  </body>
</html>