<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DOCTOR APPOINTMENT</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="DAC.css">
</head>
    <body>
  <header class="header">

    <a href="#" class="logo">
        <img src="logo.png" alt="">
    </a>

    <nav class="navbar">
        <a href="#menu">home</a>
        <a href="#about">about</a>
    </nav>

    <div class="icons">
        <div class="fas fa-search" id="search-btn"></div>
        
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>

    <div class="search-form">
        <input type="search" id="search-box" placeholder="search here...">
        <label for="search-box" class="fas fa-search"></label>
    </div>
</header>
        
        <section class="menu" id="menu">

    <h1 class="heading"><br><span><br>DOCTOR'S</span> </h1>

    <div class="box-container">

        <div class="box">
            <img src="doctor/mehedi.PNG" alt="">
            <h3>Md.Mehedi Hasan</h3>
            <div class="Dept">Haematology</div>
            <a href="AP/mehedi.php" class="btn">Get an appointment</a>
        </div>

        <div class="box">
            <img src="doctor/Rajosri.PNG" alt="">
            <h3>Rajosri Basak</h3>
            <div class="Dept">Medicine</div>
            <a href="AP/rajosri.php" class="btn">Get an appointment</a>
        </div>

        <div class="box">
            <img src="doctor/sun.PNG" alt="">
            <h3>Md.Shariar Hossain Sun</h3>
            <div class="Dept">Neuro Surgery</div>
            <a href="AP/sun.php" class="btn">Get an appointment</a>
        </div>

        <div class="box">
            <img src="doctor/hasib.PNG" alt="">
            <h3>Md.Hasibul Hasan Rasel</h3>
            <div class="Dept">Colorectal Surgery</div>
            <a href="AP/hasib.php" class="btn">Get an appointment</a>
        </div>

        <div class="box">
            <img src="doctor/sathi.PNG" alt="">
            <h3>Shathi Ara</h3>
            <div class="Dept">Gynaecology</div>
            <a href="AP/sathi.php" class="btn">Get an appointment</a>
        </div>

        <div class="box">
            <img src="doctor/rasel.PNG" alt="">
            <h3>Rasel Ialam Babu</h3>
            <div class="Dept">ENT. Head and Neck Surgery</div>
            <a href="AP/babu.php" class="btn">Get an appointment</a>
        </div>

    </div>

</section>
        <script src="doctor/script.js"></script>    
    </body>
</html>