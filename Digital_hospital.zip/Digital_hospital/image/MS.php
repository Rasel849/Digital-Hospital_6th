<!DOCTYPE php>
<php>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DIGITAL HOSPITAL STORE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="MSC.css">

</head>
<body>
<header class="header">

    <a href="#" class="logo">
        <img src="logo.png" alt="">
    </a>

    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#about">about</a>
    </nav>

    <div class="icons">
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>

    <div class="search-form">
        <input type="search" id="search-box" placeholder="search here...">
        <label for="search-box" class="fas fa-search"></label>
    </div>

   
</header>

<section class="start" id="start">

    <div class="content">
        <h3>WELCOME TO DIGITAL HOSPITAL STORE</h3>
    </div>

</section>

<section class="home" id="home">

    <h1 class="heading"> <br><br>Medicine Shop</h1>

    <div class="box-container">
    <form action="store/ms/connect.php" method="post">
        <div class="box">
            <img src="store/napa.PNG" alt="">
            <h3 >Napa Extra Tablet</h3>
            <input type="hidden" name="name"id="name"value="Napa Extra Tablet">
            <div class="price">Unit Price: ৳ 2.49 <span>(240's pack: ৳ 598.70)</span></div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal(this.value,2)" onchange="pricecal(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="tprice"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>
    <form action="store/ms/connect.php" method="post">
        <div class="box">
            <img src="store/paricel.PNG" alt="">
            <h3 >Paricel Capsule 20 mg</h3>
            <input type="hidden" name="name"id="name"value="Paricel Capsule 20 mg">
            <div class="price">Unit Price: ৳ 8.00 <span>(pack: ৳ 80.00)</span></div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_2(this.value,2)" onchange="pricecal_2(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_2"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>
    <form action="store/ms/connect.php" method="post">

        <div class="box">
            <img src="store/open.PNG" alt="">
            <h3 >Open Tablet</h3>
            <input type="hidden" name="name"id="name"value="Open Tablet">
            <div class="price">Unit Price: ৳ 4.49 <span>(pack: ৳ 35.00)</span></div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_3(this.value,2)" onchange="pricecal_3(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_3"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>
    <form action="store/ms/connect.php" method="post">

        <div class="box">
            <img src="store/ebatin.PNG" alt="">
            <h3 >Ebatin Tablet</h3>
            <input type="hidden" name="name"id="name"value="Ebatin Tablet">
            <div class="price">Unit Price: ৳ 8.00 <span>(pack: ৳ 80.00)</span></div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_4(this.value,2)" onchange="pricecal_4(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_4"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>
    <form action="store/ms/connect.php" method="post">

        <div class="box">
            <img src="store/saline.PNG" alt="">
            <h3 >Saline</h3>
            <input type="hidden" name="name"id="name"value="Saline">
            <div class="price">Unit Price: ৳ 120.00 </div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_5(this.value,2)" onchange="pricecal_5(this.value,2)">
        
        <p><h3>Total Price:৳ <span id="pricecal_5"></span></h3></p>
        <input type="hidden" name="total_price"id="total_price"value=2.5>
        
        <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>
    <form action="store/ms/connect.php" method="post">

        <div class="box">
            <img src="store/injection.PNG" alt="">
            <h3 >Injection</h3>
            <input type="hidden" name="name"id="name"value="Injection">
            <div class="price">Unit Price: ৳ 105.00</div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_6(this.value,2)" onchange="pricecal_6(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_6"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>

    <form action="store/ms/connect.php" method="post">
         <div class="box">
            <img src="store/apsol.PNG" alt="">
            <h3 >Apsol®</h3>
            <input type="hidden" name="name"id="name"value="Apsol®">
            <div class="price">Unit Price: ৳ 86.50</div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_7(this.value,2)" onchange="pricecal_7(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_7"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>

    <form action="store/ms/connect.php" method="post">
         <div class="box">
            <img src="store/asta.PNG" alt="">
            <h3>Antista®</h3>
            <input type="hidden" name="name"id="name"value="Antista®">
            <div class="price">Unit Price: ৳ 100.00</div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_8(this.value,2)" onchange="pricecal_8(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_8"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>

    <form action="store/ms/connect.php" method="post">
         <div class="box">
            <img src="store/anplep.PNG" alt="">
            <h3 >Anleptic®</h3>
            <input type="hidden" name="name"id="name"value="Anleptic®">
            <div class="price">Unit Price: ৳ 8.49 <span>(pack: ৳ 85.00)</span></div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_9(this.value,2)" onchange="pricecal_9(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_9"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>      


    <form action="store/ms/connect.php" method="post">
         <div class="box">
            <img src="store/amodis.PNG" alt="">
            <h3 >Amodis®</h3>
            <input type="hidden" name="name"id="name"value="Amodis®">
            <div class="price">Unit Price: ৳ 3.00 <span>(pack: ৳ 25.00)</span></div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_10(this.value,2)" onchange="pricecal_10(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_10"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>

    <form action="store/ms/connect.php" method="post">
         <div class="box">
            <img src="store/drop.PNG" alt="">
            <h3 >Alacot® Eye Drops</h3>
            <input type="hidden" name="name"id="name"value="Alacot® Eye Drops">
            <div class="price">Unit Price: ৳ 8.00 <span>(pack: ৳ 70.00)</span></div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_11(this.value,2)" onchange="pricecal_11(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_11"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>
    <form action="store/ms/connect.php" method="post">
         <div class="box">
            <img src="store/ass.PNG" alt="">
            <h3 >Ace®</h3>
            <input type="hidden" name="name"id="name"value="Ace®">
            <div class="price">Unit Price: ৳ 5.49 <span>(pack: ৳ 40.00)</span></div>
            <input type="number" name="quantity" id="quantity" placeholder="Quantity"oninput="pricecal_12(this.value,2)" onchange="pricecal_12(this.value,2)">
        
            <p><h3>Total Price:৳ <span id="pricecal_12"></span></h3></p>
            <input type="hidden" name="total_price"id="total_price"value=2.5>
            
            <input type="submit" value="Buy Now" class="btn">
        </div>
    </form>

    </div>

</section>
<script>function pricecal(valNum,up) {document.getElementById("tprice").innerHTML=valNum*up; }</script>
<script>function pricecal_2(valNum,up) {document.getElementById("pricecal_2").innerHTML=valNum*up; }</script>
<script>function pricecal_3(valNum,up) {document.getElementById("pricecal_3").innerHTML=valNum*up; }</script>
<script>function pricecal_4(valNum,up) {document.getElementById("pricecal_4").innerHTML=valNum*up; }</script>
<script>function pricecal_5(valNum,up) {document.getElementById("pricecal_5").innerHTML=valNum*up; }</script>
<script>function pricecal_6(valNum,up) {document.getElementById("pricecal_6").innerHTML=valNum*up; }</script>
<script>function pricecal_7(valNum,up) {document.getElementById("pricecal_7").innerHTML=valNum*up; }</script>
<script>function pricecal_8(valNum,up) {document.getElementById("pricecal_8").innerHTML=valNum*up; }</script>
<script>function pricecal_9(valNum,up) {document.getElementById("pricecal_9").innerHTML=valNum*up; }</script>
<script>function pricecal_10(valNum,up) {document.getElementById("pricecal_10").innerHTML=valNum*up; }</script>
<script>function pricecal_11(valNum,up) {document.getElementById("pricecal_11").innerHTML=valNum*up; }</script>
<script>function pricecal_12(valNum,up) {document.getElementById("pricecal_12").innerHTML=valNum*up; }</script>
<script src="store/script.js"></script>

</body>
</php>