<?php
	$name = $_POST['name'];
	$quantity = $_POST['quantity'];
	$total_price=$_POST['total_price'];
	$total_price=(double)$total_price*$quantity;
	// Database connection
	$conn = new mysqli('localhost','root','','doctor');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into ms(name,quantity,total_price) values(?, ?,?)");
		$stmt->bind_param("sid", $name,$quantity,$total_price);
		$execval = $stmt->execute();
		echo $execval;
		echo '<script>
          window.location="succeess.php";
        </script>';
		$stmt->close();
		$conn->close();
	}
?>