<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Hospital Admit</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
    <style>
        #msg {
            visibility: hidden;
            min-width: 250px;
            background-color: yellow;
            color: #000;
            text-align: center;
            border-radius: 2px;
            padding: 16px;
            position: fixed;
            z-index: 1;
            right: 30%;
            top: 30px;
            font-size: 17px;
            margin-right: 30px;
        }

        #msg.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }

        @-webkit-keyframes fadein {
            from {
                top: 0;
                opacity: 0;
            }

            to {
                top: 30px;
                opacity: 1;
            }
        }

        @keyframes fadein {
            from {
                top: 0;
                opacity: 0;
            }

            to {
                top: 30px;
                opacity: 1;
            }
        }

        @-webkit-keyframes fadeout {
            from {
                top: 30px;
                opacity: 1;
            }

            to {
                top: 0;
                opacity: 0;
            }
        }

        @keyframes fadeout {
            from {
                top: 30px;
                opacity: 1;
            }

            to {
                top: 0;
                opacity: 0;
            }
        }
    </style>
</head>

<body>
    <header class="header">

        <a href="#" class="logo">
            <img src="logo.png" alt="">
        </a>

        <nav class="navbar">
            <a href="#menu">home</a>
        </nav>
    </header>
    <br><br>
    <div class="ha">
        <form action="connect.php" method="post">

        <form>
            <h2 style="color: #fff;">HOSPITAL ADMIT</h2>

            <input type="text" name="name" id="name" placeholder="Patient Name"><br><br>
            <input type="number" name="age" id="age" placeholder="Age"><br><br>
            <input type="text" name="problem" id="problem" placeholder="Write Your Problem"><br><br>
            <input type="number" name="number" id="number" placeholder="Phone number"><br><br>
            <input type="submit" value="Submit"><br><br>

        </form>
        </form>


    </div>
</body>

</html>