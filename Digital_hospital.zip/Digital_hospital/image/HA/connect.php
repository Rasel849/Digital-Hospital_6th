<?php
	$name = $_POST['name'];
	$age = $_POST['age'];
	$problem =$_POST['problem'];
	$number =$_POST['number'];
	

	// Database connection
	$conn = new mysqli('localhost','root','','doctor');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into hospital_admit(name,age,problem,number) values(?, ?, ?,?)");
		$stmt->bind_param("sisi", $name,$age,$problem, $number);
		$execval = $stmt->execute();
		echo $execval;
		echo '<script>
          window.location="succeess.php";
        </script>';
		$stmt->close();
		$conn->close();
	}
?>